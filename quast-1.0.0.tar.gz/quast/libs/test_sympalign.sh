#python sympalign.py 1 outsymp.coords results/plantagora/nucmer_contigs_final.fasta.coords.btab results/plantagora/nucmer_velvet_contigs.fa.coords.btab
#python sympalign.py 2 outsymp.segments results/plantagora/nucmer_contigs_final.fasta.coords.btab results/plantagora/nucmer_velvet_contigs.fa.coords.btab
python sympalign.py 2 ../results/plantagora/out.segments ../results/plantagora/
#*.btab
