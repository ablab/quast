#!/bin/bash
make -C libs/MUMmer3.23-osx/ clean
make -C libs/MUMmer3.23-linux/ clean
rm -f *.pyc libs/*.pyc latest
rm -rf results_*
rm clean.sh~
